#include <stdio.h>

int main ()
{
   printf ("It is a new code.\n");
}
